26 april 2009
Final Release

Project started in august 2008 and RuneCrafter began in 5th February 2009

Requirements:
Microsoft XNA Framework Redistributable 3.0

Setup will automatic install or you can manually download here:
http://www.microsoft.com/downloads/details.aspx?familyid=6521D889-5414-49B8-AB32-E3FFF05A4C50&displaylang=en

Contact Info:
Han Lin Yap
codler [at] gmail.com
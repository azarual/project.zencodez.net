// JavaScript Document
jQuery.fn.defaultInput = function(o) {
	var o = o || this.val();
	this.each(function() {
		if ($(this).val() == '') {
			$(this).val(o);
		}
		$(this).focus(function() {
			if (o == $(this).val()) {
				$(this).val('');
			}
		});
		$(this).blur(function() {
			if ('' == $(this).val()) {
				$(this).val(o);
			}
		});
	});
}
How to use?
You need to have jQuery and import defaulttext plugin.
eg. <script type="text/javascript" src="defaultinput.plugin.js"></script>

You only need to write a single line of javascript code to setup one input field.
eg. $('input#username').defaultInput('Username');
The input field with id username have now been set to the defaulttext "Username".




Written by Han Lin Yap